# probabilistic-word-embeddings v0.15.1

Probabilistic Word Embedding module for Python. Built with TensorFlow 2.x and TensorFlow probability.

[Documentation is available here.](https://ninpnin.github.io/probabilistic-word-embeddings/)

## Colab demo

A demo of the project can be run on [Google Colab](https://colab.research.google.com/drive/1dGqWn7SMqg-fGzVUGzXSOUmsX8m9k5k2).
